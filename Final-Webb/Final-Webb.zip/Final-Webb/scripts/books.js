/* DO NOT REMOVE ANY OF THE COMMENT LINES */

    function confirmRating()
{
    /* Compete the code to display the values from the form in an alert message box as shown in the demo video. */
    /* var myWindow = */ 
    window.alert("Thank you for rating our book for" + 
                ". Your rating of" + document.getElementById("rbutton").value + 
                 "will be emailed to:" + document.getElementById("TextEmailAddress").value);
    
}

/* document.getElementById("book").value + */
